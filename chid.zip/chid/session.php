<?php
include('connection.php');
session_start();
if(isset($_SESSION['Receptionist'])){;
   $sql = "SELECT * FROM user WHERE user_id = '".$_SESSION['Receptionist']."'";
   $query = $conn->query($sql);
   $curSession = $query->fetch_assoc();        

}

?>