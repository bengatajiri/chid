<?php
	include('includes/connection.php');
	session_start();

// if(isset($_POST['edit'])){

		$depature_id = $_POST['id'];
		$Depature = $_POST['Depature'];
		$Region = $_POST['Region'];
		$Status = $_POST['Status'];
		
	
		$sql = "UPDATE depature SET depature_name = '$Depature',region_id='$Region', status='$Status' WHERE depature_id = '$depature_id'";

	
		if($conn->query($sql)){
			
			$_SESSION['success'] = 'depature updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	// }
	// else{
	// 	$_SESSION['error'] = 'Select user to edit first';
	// }

	header('location: view depature.php');
	

	 ?>