<?php
$conn = mysqli_connect("localhost","root","","project");

if (!$conn) {
	die("connect error".mysqli_connect_error());
	# code...
}else{
	
}
?>