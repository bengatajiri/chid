<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php')?>

<body class="bg-gradient-success">

	<div class="container">

<?php 
include('includes/connection.php'); 
$destination = mysqli_real_escape_string($conn, $_GET['id']);
		$check_id = "SELECT * FROM destination where destination_id = '".$destination."'";
		$query = $conn->query($check_id);
		$row = $query->fetch_assoc();
		$Destination = $row['destination_name'];
		 $Status = $row['status'];
				$Region = $row['region_id'];

	?> 

		<!-- Outer Row -->
		<div class="row justify-content-center">


			<div class="col-xl-6 col-lg-12 col-md-6">

				<div class="card o-hidden border-0 shadow-lg my-5">
					<div class="card-body p-0">
						<!-- Nested Row within Card Body -->


						<div class="row">
					<div class="col-lg-12">
						<div class="p-5">
							<div class="text-center">
								<h1 class="h4 text-gray-900 mb-4">EDIT ADD DESTINATION!</h1>
							</div>
							<form  action = "Adddestination_edit.php" method = "POST">
							 <div class="form-group">
											<input type="text" class="form-control form-control-user" id="Destination"  name="Destination" value="<?php echo $Destination ?>"placeholder="Enter destination station" required>
										</div> 
										<input type="hidden" class="form-control form-control-user" name="id" value="<?php echo $destination?>"
>

					<div class="form-group">
			<select class="form-control" name="Status" value="<?php echo $Status ?>">
			 <option selected="" disabled select>select Status </option>
					<option selected="active">active</option>
						 <option selected="inactive">inactive</option>

			</select>   
	</div>

										<div class="form-group">
											 <select class="form-control" value="<?php echo $Region ?>" name="Region">
			 <option selected=""disabled select>select Region</option>
		 <?php
													$sql = "SELECT * FROM region";
													$query = $conn->query($sql);
													while($prow = $query->fetch_assoc()){
														echo "
															<option value='".$prow['region_id']."'>".$prow['region_name']."</option>
														";
													}
												?>
			</select>
										</div> 

										<button type="submit" name="submit" class="btn btn-success btn-user btn-block">Register</button>
										<!--  <input class="form-group" type="submit" class="btn btn-success btn-user btn-block"> Submit --> 
										 </form>
										 </div> 

								</div>
							</div>
						</div>
						</div>
					
<!-- script -->
<?php include('includes/script.php'); ?>

</body>

</html>

		