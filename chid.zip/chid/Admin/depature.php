<?php
//if (!isset($_POST["submit"])) {
include('includes/connection.php');
$Depature=$_POST["Depature"];


// $Role=$_POST["Role"];
// $Phone=$_POST["Phone"];
// $Email=$_POST["Email"];
// $Password=$_POST["Fname"];

 
 $query1=mysqli_query($conn,"insert into depature(depature_name)values('$Depature')");
 if  (!$query1) {
 	die("error".mysqli_error($conn));

 }else{
 	echo "succesful registered";
 }
//}
//else {
	//echo "Fill form first";
//}
?>