<?php
	include('includes/connection.php');
	session_start();

// if(isset($_POST['edit'])){

		$user_id = $_POST['id'];
		$Fname = $_POST['Fname'];
		$Lname = $_POST['Lname'];
		$Phone = $_POST['Phone'];
		$Email = $_POST['Email'];
		$Region = $_POST['Region'];
		
	
		$sql = "UPDATE user SET f_name = '$Fname', l_name = '$Lname', phone_no = '$Phone', email='$Email', region_id='$Region' WHERE user_id = '$user_id'";

	
		if($conn->query($sql)){
			
			$_SESSION['success'] = 'user updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	// }
	// else{
	// 	$_SESSION['error'] = 'Select user to edit first';
	// }

	header('location: Addreceptionist.php');
	

	 ?>