
<?php
include('includes/connection.php');
session_start();
?>



<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php');?>
 

<body id="page-top">


  <!-- Page Wrapper -->
  <div id="wrapper">

    
    <!-- Sidebar -->
    <?php include('includes/sidebar.php');?>
    <!-- end sidebar -->

    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include('includes/topbar.php');?>

   <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">BUS PARCEL MANAGEMENT ROUTES</h1>
          <!-- Table body -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-success">List of registered destination stations</h6>
            </div>




             <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>

      <!-- Table -->
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                    <th>Destination_ID</th>
                      <th>Destination_name</th>
                      <th>Region</th>
                      <th>Status</th>
                       <th>Action</th>
                    </tr>
                  </thead>
                
                   <tbody>
                    <?php
                    include('includes/connection.php');
                    ?>
                  <?php
                    $sql = "SELECT destination_id, destination_name,region_name,status FROM destination INNER JOIN region USING (region_id)";
                    $query1 = $conn->query($sql);
                    while($row = $query1->fetch_assoc()){
                      ?>
                       <tr>
                          <td><?php echo $row['destination_id']; ?></td>
                          <td><?php echo $row['destination_name']; ?></td>
                          <td><?php echo $row['region_name']; ?></td>
                          <td><?php echo $row['status']; ?></td>
                           <td>
                            <a href="Adddestinationform_edit.php?id=<?php echo $row['destination_id']; ?>" class='btn bg-purple'><i class='fa fa-edit'></i></a> 
                          </td>
                        </tr>
                       <?php
                    }
                  ?> 
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

          
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<!-- script -->
<?php  include('includes/script.php');?>

</body>

</html>