<?php
include('includes/connection.php');
session_start();
if(isset($_SESSION['Admin'])){;
   $sql = "SELECT * FROM user WHERE user_id = '".$_SESSION['Admin']."'";
   $query = $conn->query($sql);
   $curSession = $query->fetch_assoc();        

}

?>