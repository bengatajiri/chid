<?php
//if (!isset($_POST["submit"])) {
include('includes/connection.php');
$Fname=$_POST["Fname"];
$Lname=$_POST["Lname"];
$Region=$_POST["Region"];
$Role=$_POST["Role"];
$Phone=$_POST["Phone"];
$Email=$_POST["Email"];
$Password=$_POST["Fname"];
$Password = password_hash($Password, PASSWORD_DEFAULT);
 
 $query1=mysqli_query($conn,"insert into user(f_name, l_name, email, region_id, role, phone_no,password)values('$Fname','$Lname','$Email','$Region','$Role', '$Phone','$Password')");
 if  (!$query1) {
 	die("error".mysqli_error($conn));

 }else{
 	echo "succesful registered";
 }
//}
//else {
	//echo "Fill form first";
//}
?>