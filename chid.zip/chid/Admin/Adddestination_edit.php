<?php
	include('includes/connection.php');
	session_start();

// if(isset($_POST['edit'])){

		$destination_id = $_POST['id'];
		$Destination = $_POST['Destination'];
		$Region = $_POST['Region'];
		$Status = $_POST['Status'];
		
	
		$sql = "UPDATE destination SET destination_name = '$Destination',region_id='$Region', status='$Status' WHERE destination_id = '$destination_id'";

	
		if($conn->query($sql)){
			
			$_SESSION['success'] = 'destination updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	// }
	// else{
	// 	$_SESSION['error'] = 'Select user to edit first';
	// }

	header('location: view destination.php');
	

	 ?>