
<?php
include ('includes/connection.php');
session_start();
?>



<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php')?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
   <?php include('includes/sidebar.php');?>
    <!-- End of Sidebar  -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
       
     <?php include('includes/topbar.php');?>

          
        
      <!-- script     -->
     <?php include('includes/script.php');?>
</div>
</div>
</div>

  
</body>

</html>
