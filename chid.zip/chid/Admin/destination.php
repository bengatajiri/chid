<?php
//if (!isset($_POST["submit"])) {
include('includes/connection.php');
$Destination=$_POST["Destination"];


// $Role=$_POST["Role"];
// $Phone=$_POST["Phone"];
// $Email=$_POST["Email"];
// $Password=$_POST["Fname"];

 
 $query1=mysqli_query($conn,"insert into destination(destination_name)values('$Destination')");
 if  (!$query1) {
 	die("error".mysqli_error($conn));

 }else{
 	echo "succesful registered";
 }
//}
//else {
	//echo "Fill form first";
//}
?>