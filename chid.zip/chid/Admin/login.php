<?php
session_start();
include('includes/connection.php');

$Email=$_POST['Email'];
$Password=$_POST['Password'];


$sql= "SELECT * from user where  email='$Email'";
$query1 = $conn->query($sql);


if($query1->num_rows < 1){
	$_SESSION['error'] = 'Cannot find that email';
}
else{

	$row = $query1->fetch_assoc();
	if(password_verify($Password, $row['password'])){ 

				if($row['role']=="Admin"){
				$_SESSION['Admin'] = $row['user_id'];
				$_SESSION['email']=$Email;

			}
				else if($row['role']=="Manager") {
			  	$_SESSION['Manager'] = $row['user_id'];
			  	$_SESSION['email']=$Email;
			  }
			  else if ($row['role']=="Receptionist") {
			  	$_SESSION['Receptionist'] = $row['user_id'];
			  	$_SESSION['email']=$Email;
			  }

		}
			else{
				$_SESSION['error'] = 'Incorrect password';

			}
	}
	header('location:index.php');


?>

  
