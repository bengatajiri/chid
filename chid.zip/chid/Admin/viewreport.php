<!DOCTYPE html>
<html>
<head>
	<title>View report</title>
</head>
<body>
<?php
include('head.php');
include('connection.php');
$query1=mysqli_query($conn,"SELECT depature_name, destination_name,parcel_code,type,amount_paid,arrival_date,status_name FROM `parcel` LEFT JOIN   `depature` USING(depature_id) LEFT JOIN `destination` USING(destination_id) LEFT JOIN `status` USING(status_id)");

if (!$query1) {
	die("Query error:".mysqli_error($conn));

}
else{
	$Amount=mysqli_num_rows($query1);
	echo "There are $Amount parcels sent";
?>

<table border="1">
	<tr><th>Parcel_code</th><th>Type</th><th>Amount_paid</th><th>Arrival_date</th><th>Depature</th><th>Destination</th><th>Status</th></tr>
	<?php
	$count=0;
	for ($count=0; $count <mysqli_num_rows($query1);
	 $count++) { 

		$our_data=mysqli_fetch_array($query1);
		$Parcel_code=$our_data['parcel_code'];
		$Parcel_type=$our_data['type'];
		$Amount_paid=$our_data['amount_paid'];
		$Arrival_date=$our_data['arrival_date'];
		$Depature=$our_data['depature_name'];
		$Destination=$our_data['destination_name'];
		$Status=$our_data['status_name'];
		
		?>
		<tr><td><?php echo $Parcel_code?></td><td><?php echo $Parcel_type ?></td><td><?php echo $Amount_paid?></td><td><?php echo $Arrival_date?></td><td><?php echo $Depature?></td><td><?php echo $Destination?></td><td><?php echo $Status?></td></tr>
		<?php
	}
}
?>
	
</table>

</body>
</html>
