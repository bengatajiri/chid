<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php');?>
<body class= "bg-gradient-success">
 
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-8 col-md-6">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-5">
            <!-- Nested Row within Card Body -->
            <!-- <div class="row"> -->
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">ADD DEPATURE</h1>
                  </div>
                 
                    <form class="user"action="depature.php"  method="POST">

                    <div class="form-group">
                      <input type="text" class="form-control" name="Depature"  placeholder="Enter Depature station...">
                    </div>
                    
                   <div class="form-group">
                     <select class="form-control" name="State">
       <option selected=""disabled select>select State</option>
    <option value="Active">Active</option>
    <option value="Dormant">Dormant</option>
  </select>
                    </div>
                    <button type="submit" name="submit" class="btn btn-success btn-user btn-block">ADD </button>
        </form>
                </div>
              </div>
            </div>
          </div>
        </div>

          <div class="col-xl-6 col-lg-8 col-md-6">

<div class="card o-hidden border-0 shadow-lg my-5">

 <div class="card-body p-5">
            <!-- Nested Row within Card Body -->
            <!-- <div class="row"> -->
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">ADD DESTINATION</h1>
                  </div>
                 
                    <form class="user"action="destination.php"  method="POST">

                    <div class="form-group">
                      <input type="text" class="form-control" name="Destination"  placeholder="Enter Destination station...">
                    </div>
                   
                   <div class="form-group">
                       <select class="form-control" name="State">
       <option selected=""disabled select>select State</option>
    <option value="Active">Active</option>
    <option value="Dormant">Dormant</option>
  </select>
                    </div>

                    <button type="submit" name="submit" class="btn btn-success btn-user btn-block">ADD</button>
          <div class="text-center">
    
          </div>
        </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        </div>

      </div>
<!-- script -->
<?php include('includes/script.php');?>
</body>

</html>

