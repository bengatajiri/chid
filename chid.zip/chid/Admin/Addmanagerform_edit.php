<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php');?>

<body class="bg-gradient-success">

  <div class="container">

<?php 
include('includes/connection.php'); 
$user = mysqli_real_escape_string($conn, $_GET['id']);
    $check_id = "SELECT * FROM user where user_id = '".$user."'";
    $query = $conn->query($check_id);
    $row = $query->fetch_assoc();
    $Fname = $row['f_name'];
     $Lname = $row['l_name'];
      $Email = $row['email'];
       $Phone = $row['phone_no'];
        // $Role = $row['role'];
        $Region = $row['region_id'];

  ?> 

    <!-- Outer Row -->
    <div class="row justify-content-center">


      <div class="col-xl-6 col-lg-12 col-md-6">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->


            <div class="row">
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">EDIT ADD MANAGER!</h1>
              </div>
              <form  action = "addmanageredit.php" method = "POST">
               <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="F_name"  name="Fname" value="<?php echo $Fname ?>"placeholder="first name" required>
                    </div> 
                    <input type="hidden" class="form-control form-control-user" name="id" value="<?php echo $user ?>">
                     <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="L_name" name="Lname" value="<?php echo $Lname ?>"  placeholder="last name" required>
                    </div>               
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="customer_phone"name="Phone" pattern="[+]{1}[2]{1}[5]{1}[5]{1}[0-9]{9}" minlength="13" title="Phone number must start with: +255 followed by any 9 digit"  value="<?php echo $Phone ?>" placeholder="Phone number" required>
                  </div>
                    <div class="form-group">
                      <input type="email" class="form-control form-control-user" id="customer_email" name="Email" value="<?php echo $Email ?>"  placeholder="Email Address" required>
                  </div>
                          
                    <div class="form-group">
                       <select class="form-control" value="<?php echo $Region ?>" name="Region">
       <option selected=""disabled select>select Region</option>
     <?php
                          $sql = "SELECT * FROM region";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['region_id']."'>".$prow['region_name']."</option>
                            ";
                          }
                        ?>
      </select>
                    </div> 

                    <button type="submit" name="submit" class="btn btn-success btn-user btn-block">Register</button>
                    <!--  <input class="form-group" type="submit" class="btn btn-success btn-user btn-block"> Submit --> 
                     </form>
                     </div> 

                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
          

 <!-- script -->
<?php include('includes/script.php');?>


</body>

</html>

  
    