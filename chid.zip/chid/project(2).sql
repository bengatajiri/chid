-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 07, 2020 at 02:31 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(20) NOT NULL,
  `r_names` varchar(200) NOT NULL,
  `r_phone` varchar(20) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `r_names`, `r_phone`) VALUES
(1, 'Maya', '0754-321-345'),
(2, 'Renata Maya', '0754-321-345'),
(3, 'Joyce Japhet', '0632-567-567');

-- --------------------------------------------------------

--
-- Table structure for table `depature`
--

DROP TABLE IF EXISTS `depature`;
CREATE TABLE IF NOT EXISTS `depature` (
  `depature_id` int(11) NOT NULL AUTO_INCREMENT,
  `depature_name` varchar(50) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`depature_id`),
  KEY `region_id` (`region_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depature`
--

INSERT INTO `depature` (`depature_id`, `depature_name`, `region_id`) VALUES
(3, 'Moshi-Mjini', 1),
(5, 'Arusha-Mjini', 2),
(6, 'Morogoro-Msamvu', 4),
(8, 'Dar-es-salaam-Ubungo', 3);

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

DROP TABLE IF EXISTS `destination`;
CREATE TABLE IF NOT EXISTS `destination` (
  `destination_id` int(11) NOT NULL AUTO_INCREMENT,
  `destination_name` varchar(50) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`destination_id`),
  KEY `region_id` (`region_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`destination_id`, `destination_name`, `region_id`) VALUES
(3, 'Moshi-Mjini', 1),
(5, 'Arusha-Mjini', 2),
(6, 'Morogoro-Msamvu', 4),
(8, 'Dar-es-salaam-Ubungo', 3);

-- --------------------------------------------------------

--
-- Table structure for table `parcel`
--

DROP TABLE IF EXISTS `parcel`;
CREATE TABLE IF NOT EXISTS `parcel` (
  `parcel_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `amount_paid` int(220) NOT NULL,
  `parcel_code` varchar(20) NOT NULL,
  `registered_date` datetime NOT NULL,
  `depature_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sender_id` int(20) NOT NULL,
  `status` varchar(200) NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`parcel_id`),
  UNIQUE KEY `parcel_code` (`parcel_code`),
  KEY `customer_id` (`customer_id`),
  KEY `depature_id` (`depature_id`),
  KEY `destination_id` (`destination_id`),
  KEY `user_id` (`user_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parcel`
--

INSERT INTO `parcel` (`parcel_id`, `type`, `amount_paid`, `parcel_code`, `registered_date`, `depature_id`, `destination_id`, `customer_id`, `user_id`, `sender_id`, `status`) VALUES
(32, 'shoes', 5000, 'PNG581', '2020-07-06 10:34:51', 3, 8, 1, 40, 0, 'pending'),
(33, 'Phone', 500000, 'XGK680', '2020-07-07 12:18:43', 3, 8, 2, 40, 43, 'pending'),
(34, 'shoes', 5000, 'OVF621', '2020-07-07 09:46:11', 8, 8, 3, 53, 44, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `parcel_user`
--

DROP TABLE IF EXISTS `parcel_user`;
CREATE TABLE IF NOT EXISTS `parcel_user` (
  `parcel_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `parcel_id` (`parcel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
CREATE TABLE IF NOT EXISTS `region` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(50) NOT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`region_id`, `region_name`) VALUES
(1, 'Kilimanjaro'),
(2, 'Arusha'),
(3, 'Dar-es-salaam'),
(4, 'Morogoro'),
(5, 'Kigoma'),
(6, 'Dodoma'),
(7, 'Iringa'),
(8, 'Mbeya'),
(9, 'Shinyanga'),
(10, 'Singida'),
(11, 'Mwanza'),
(12, 'Tanga'),
(13, 'Rukwa'),
(14, 'Ruvuma'),
(15, 'Mtwara'),
(16, 'Songwe'),
(17, 'Mara'),
(18, 'Tabora'),
(19, 'Manyara'),
(20, 'Lindi'),
(21, 'Geita'),
(22, 'Kagera'),
(23, 'Njombe'),
(24, 'Katavi'),
(25, 'Pwani'),
(26, 'Simiyu');

-- --------------------------------------------------------

--
-- Table structure for table `sender`
--

DROP TABLE IF EXISTS `sender`;
CREATE TABLE IF NOT EXISTS `sender` (
  `sender_id` int(11) NOT NULL,
  `s_names` varchar(200) NOT NULL,
  `s_phone` varchar(20) NOT NULL,
  PRIMARY KEY (`sender_id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sender`
--

INSERT INTO `sender` (`sender_id`, `s_names`, `s_phone`) VALUES
(41, 'Ummy ', '0745-896-123'),
(1, 'Deogracious Maya', '0785-345-213'),
(42, 'Deogracious Maya', '0745-896-123'),
(43, 'Deogracious Maya', '0745-896-123'),
(44, 'Mary Marko', '0674-890-234');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `role` varchar(30) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `region_id` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `f_name`, `l_name`, `email`, `password`, `phone_no`, `role`, `region_id`) VALUES
(27, 'Angel', 'Mathew', 'markmathew@gmail.com', '$2y$10$Yn5AcCijRhDyvuHP0XmvE.TgiWo.wfTz/7p/jxkPUoTOTFLTj9FY.', '+255678907654', 'Manager', 1),
(34, 'Anna', 'Paul', 'annapaul@gmail.com', '$2y$10$D.qKiZBc.YWUceYa8iXPH.T9NT56GNr/69Uvrvc0iEEQ58keUEWq.', '+255456789043', 'Manager', 11),
(35, 'Mary', 'John', 'maryjohn@gmail.com', '$2y$10$Psceeb6H3p5mfGrm6JKaNekpBtXBsdAl/1VjlaCI.DPRm58rdUt46', '+255456789234', 'Admin', 12),
(36, 'John', 'Joseph', 'johnjoseph@gmail.com', '$2y$10$m.dPYqm7ZhstrrBf8AeXLuj2O6R5ffcpx9U6H90o89Q..j6Ehvlra', '+255678903412', 'Manager', 6),
(38, 'Joe', 'John', 'joejohn@gmail.com', '$2y$10$WT37VD7Eq6c4mMlr/4bGP.Ws5EA02xxcwGku2Xl0qg6.KqTnkagLe', '+255678543211', 'Receptionist', 8),
(40, 'Fredy', 'Kimaro', 'fredykimaro@gmail.com', '$2y$10$5EbjkHdw5j7hOcz14QacU.BM4ZTA8a3Horn84kzslnGtaI1VuGv2m', '+255678905678', 'Receptionist', 1),
(41, 'Dina', 'Humprey', 'dinahumprey@gmail.com', '$2y$10$tQq3Tvn8x7nIou.SjHC7bOpr7RkRUVdPZ4J7LiefiB8/ggbCl9Yye', '+255678904567', 'Receptionist', 5),
(42, 'Asted', 'Augustine', 'astedaugustine@gmail.com', '$2y$10$o4J6YeWtJuRpkKQFlFNo/uB/BSlWYSgX0y4grqf0EvgGP36EWAqwm', '+255678909754', 'Manager', 7),
(43, 'Paula', 'White', 'paulawhite@gmail.com', '$2y$10$4fEpGkyuctDQjbEKxwB7muB6KQiFt6JO71pYRQk6MlGgErbyjk8vu', '+255678907652', 'Manager', 20),
(44, 'Mathew', 'John', 'mathewjohn@gmail.com', '$2y$10$KrtiixC8qBkprEDDazB61.dKDbbWR4QneP3o3R1ZmLcu.9IaD09xO', '+255678987654', 'Manager', 7),
(45, 'Mary', 'Doe', 'marydoe@gmail.com', '$2y$10$fgEkaKwPXT2iwsbK5HaAf.FmU47UkWttRZLhqaBJbRwqysc6KrWSS', '+255567890765', 'Manager', 10),
(46, 'Renata', 'Maya', 'remaya@gmail.com', '$2y$10$D2ZQQO/U1qwe4JXjVemNLeo7jojk2VBBsFAKtpeALXMdB/0f3YfXG', '+255678905643', 'Manager', 9),
(47, 'Leah', 'Herman', 'leahherman@gmail.com', '$2y$10$rwkvXS/ijkQ1Na.4ZNNxfO.R5EsDGZtO7bGAJauN4v7zysUJqBpJe', '+255678908765', 'Manager', 6),
(48, 'Judith', 'Anael', 'judyanael@gmail.com', '$2y$10$.CxNvMqOA/Gtr81kqnoPqe02yhFe9YwAl1SyRBnKJLxrv2ujD1l6m', '+255754873316', 'Manager', 12),
(49, 'Teddy', 'Mathew', 'tedmathew@gmail.com', '$2y$10$CpgXuXNnmjgbWFPFGXXUAOyg2OJvt/d2Ohl/uy4EL4RXm.m4P7eEq', '+255678908765', 'Manager', 13),
(50, 'Lina', 'Abby', 'linaabby@gmail.com', '$2y$10$9mpUcl3FhzUuPXeLanfsvO6I5kwI5meFg6tPwxyUs1/Db/FH38xAO', '+255678908754', 'Manager', 13),
(51, 'Mary', 'George', 'marygeorge@gmail.com', '$2y$10$52Ey54oQ7LyI8SOkOzYmHO4fYk1BGeXRVllbjVLsaXahC0V.JSSky', '+255678908763', 'Manager', 13),
(52, 'Judy', 'John', 'judyjohn@gmail.com', '$2y$10$cdo9RfpkoGdbihjTZf9oy.QrGxA4wqEghxjeNglCBdc1phGpvAOui', '+255678908762', 'Receptionist', 9),
(53, 'Lebron', 'James', 'lebronjames@gmail.com', '$2y$10$XBj4ksGz13ie29T8BgdYRuoYGtF15NU/xezc/XalKrV6WKVTgi63m', '+255678908762', 'Receptionist', 5);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
