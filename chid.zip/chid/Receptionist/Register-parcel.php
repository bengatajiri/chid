<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php')?>

<body class="bg-gradient-success">

  <div class="container">

    <!-- !-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-12 col-md-6"> 

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">REGISTER PARCEL!</h1>
              </div>

              <form class="user"action="parcelregister.php" method="POST">

                 <div class="form-group">
                    <input type="text" class="form-control" placeholder="Sender names" name="Sname">
                  </div>
                 <div class="form-group">
  <input id="phonenum" type="tel" class="form-control" placeholder="sender_phone:  0789-987-432
  " pattern="^\d{4}-\d{3}-\d{3}$" required name="Sphone" >
    </div>
          
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="receiver names" name="Rname">
                  </div>
                  
                      <div class="form-group">
  <input id="phonenum" type="tel" class="form-control" placeholder="receiver_phone:  0789-987-432
  " pattern="^\d{4}-\d{3}-\d{3}$" required name="Rphone" >
    </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="exampleParceltype" placeholder="parcel_type" name="Parcel_type">
                </div>
<div class="form-group">
                  <input type="number" class="form-control" id="exampleAmountpaid" placeholder="amount_paid" name="Amount_paid">
                </div>  
             

   <div class="form-group">
     
    <select class="form-control" name="Depature">
       <option selected=""disabled select>Depature location</option>

        <?php
        include ('includes/connection.php');
                          $sql = "SELECT * FROM depature";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['depature_id']."'>".$prow['depature_name']."</option>
                            ";
                          }
                        ?>
      </select>   
  </div>
    
   <div class="form-group">
     <select class="form-control" name="Destination">
      <option selected="" disabled select>Destination location</option>
    <?php
        include('includes/connection.php');
                          $sql = "SELECT * FROM destination";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['destination_id']."'>".$prow['destination_name']."</option>
                            ";
                          }
                        ?>
      </select>
  </div>
  
                  <button type="submit" name="submit" class="btn btn-success btn-user btn-block">Register</button>
              </form>
            </div>
          </div>
        </div>
          </div>
        </div>

      </div>

    </div>

  </div>
<!-- script -->
<?php include('includes/script.php')?>

</body>

</html>
