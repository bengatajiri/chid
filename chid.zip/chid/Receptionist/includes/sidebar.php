

<?php include('header.php');?>
  <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
        <div class="sidebar-brand-icon">
          <i class="fa fa-bus"></i>
        </div>
        <div class="sidebar-brand-text mx-3">BUS PARCEL <sup>MANAGEMENT</sup></div>
      </a>

      <!-- Divider -->
       <hr class="sidebar-divider my-3">
     <!--  Nav Item  -->
 <li class="nav-item">
      <a class="nav-link" href="Receptionist.php">
        <i class="fa fa-home"></i>
          <span>Receptionist</span>
        </a>
      </li>

        

      <!-- Divider -->
      <hr class="sidebar-divider my-3">
      <!-- Nav Item  -->
      <li class="nav-item">
        <a class="nav-link" href="Register-parcel.php">
          <i class="fa fa-edit"></i>
          <span>Register-parcel</span></a>
      </li>



 <!-- Divider -->
      <hr class="sidebar-divider my-3">
      <!-- Nav Item  -->
      <li class="nav-item">
        <a class="nav-link" href="View-parcel-sent.php">
          <i class="fa fa-folder-open"></i>
          <span>View sent parcel</span></a>
      </li>

    <!-- Divider -->   
 <hr class="sidebar-divider my-3">

 <!-- Nav Item  -->
      <li class="nav-item">
        <a class="nav-link" href="View-parcel-received.php">
          <i class="fa fa-check-square"></i>
          <span>View arrived parcel</span></a>
      </li>


     <!--  Divider -->
      <hr class="sidebar-divider d-none d-md-block">



   <!--    Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
