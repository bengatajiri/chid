<?php

session_start();
//if (!isset($_POST["submit"])) {
include('includes/connection.php');

$Sname=$_POST["Sname"];
$Sphone=$_POST["Sphone"];
$Rname=$_POST["Rname"];
$Rphone=$_POST["Rphone"];
$Parcel_type=$_POST["Parcel_type"];
$Amount_paid=$_POST["Amount_paid"];
$Depature=$_POST["Depature"];
$Destination=$_POST["Destination"];
$Receptionist=$_SESSION['Receptionist'];


// Start generate customer Id...............
$query=mysqli_query($conn,"select max(customer_id) as Id from customer");
 

if($query->num_rows<1){
	$customerId = 1;
}
else{
	$dbId = $query->fetch_assoc();
	$customerId = $dbId['Id']+1;
}
// End generate customer Id...............

$query=mysqli_query($conn,"select max(sender_id) as Id from sender");
 

if($query->num_rows<1){
	$senderId = 1;
}
else{
	$dbId = $query->fetch_assoc();
	$senderId = $dbId['Id']+1;
}




// Start auto generate parcel code
$letters = '';
$numbers = '';

foreach (range('A', 'Z') as $char) {
	$letters .= $char;
}

for ($i=0; $i < 10; $i++) { 
	$numbers .= $i;
}

$code= substr(str_shuffle($letters), 0, 3).substr(str_shuffle($numbers), 0, 3);
// End auto generate parcel code

$Registered_date = date('Y-m-d h:i:s');


 $query= mysqli_query($conn,"insert into sender(sender_id,s_names,s_phone ) values
  ('$senderId','$Sname','$Sphone')");

if ($query) {
	
$query= mysqli_query($conn,"insert into customer (customer_id,r_names, r_phone) values
  ('$customerId','$Rname','$Rphone')");



if ($query) {
	
 	 $query=mysqli_query($conn,"insert into parcel (type, amount_paid, registered_date,  user_id ,parcel_code, depature_id, destination_id, customer_id,sender_id)
 	 	values('$Parcel_type','$Amount_paid','$Registered_date', '$Receptionist','$code','$Depature','$Destination','$customerId','$senderId')");
		
		

 	  if($query){

 	    echo "succesful registered";
    }
 }
}


?>  
