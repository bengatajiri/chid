<?php
include ('includes/session.php');
?>




<!DOCTYPE html>
<html lang="en">

<?php include('includes/header.php')?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
     <?php include('includes/sidebar.php');?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        
         <!-- Topbar Navbar -->
         <?php include('includes/topbar.php')?>
         
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Tables</h1>
          <p class="mb-4">List of registered parcels</p>

          <!-- Table body -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-success">List of registered parcels</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Receiver names</th>
                      <th>Phone_no</th>
                      <th>Parcel code</th>
                      <th>type</th>
                      <th>Amount paid</th>
                      <th>Sender names</th>
                      <th>Phone_no</th>
                      <th>Destination</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include('includes/connection.php');
                    ?>
                  <?php
                    $sql = "SELECT parcel_id,r_names,r_phone, s_names,s_phone,parcel_code,type,amount_paid,destination_name FROM parcel LEFT JOIN customer USING(customer_id) LEFT JOIN  sender USING (sender_id) LEFT JOIN destination USING(destination_id) LEFT JOIN region USING(region_id) where region_id = '".$curSession['region_id']."'" ;
                    $query1 = $conn->query($sql);
                    while($row = $query1->fetch_assoc()){
                      
                      ?>
                        <tr>
                          <td><?php echo $row['r_names']; ?></td>
                          <td><?php echo $row['r_phone']; ?></td>
                          <td><?php echo $row['parcel_code']; ?></td>
                          <td><?php echo $row['type']; ?></td>
                          <td><?php echo $row['amount_paid']; ?></td>
                          <td><?php echo $row['s_names']; ?></td>
                          <td><?php echo $row['s_phone']; ?></
                          <td><?php echo $row['destination_name']; ?></td>                               
                        </tr>
                      <?php
                     
                    }
                  ?> 
                </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
     

 <?php 
      include('includes/connection.php');
      ?>
     

  
  
  <!-- script -->
 <?php include('includes/script.php')?>

</body>

</html>
