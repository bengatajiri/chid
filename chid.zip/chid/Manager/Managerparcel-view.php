
<?php
include('includes/connection.php');
session_start();
?>



<!DOCTYPE html>
<html lang="en">

<!-- header -->

<?php
include('includes/header.php');
?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    
<?php
include('includes/sidebar.php');
?>
    

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php include('includes/topbar.php');?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Tables</h1>
          <p class="mb-4">List of registered parcels</p>

          <!-- Table body -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-success">LIST OF REGISTERED PARCELS</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Parcel code</th>
                      <th>type</th>
                      <th>Amount paid</th>
                      <th>Arrival_date</th>
                      <th>Depature</th>
                      <th>Destination</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include('includes/connection.php');
                    ?>
                  <?php
                    $sql = "SELECT  parcel_code, type, amount_paid, arrival_date, depature_name, destination_name ,status_name FROM parcel LEFT JOIN depature USING(depature_id) LEFT JOIN destination USING(destination_id) LEFT JOIN status USING(status_id)";

                    $query1 = $conn->query($sql);
                    while($row = $query1->fetch_assoc()){
                      ?>
                        <tr>

                          <td><?php echo $row['parcel_code']; ?></td>
                          <td><?php echo $row['type']; ?></td>
                          <td><?php echo $row['amount_paid']; ?></td>
                          <td><?php echo $row['arrival_date']; ?></td>
                            <td><?php echo $row['depature_name']; ?></td>
                              <td><?php echo $row['destination_name']; ?></td>
                                <td><?php echo $row['status_name']; ?></td>
                                
                        </tr>
                      <?php
                    }
                  ?> 
                </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
     

 <?php 
      include('includes/connection.php');
      ?>
     

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-success" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- script -->
<?php include('includes/script.php')?>
</body>

</html>
