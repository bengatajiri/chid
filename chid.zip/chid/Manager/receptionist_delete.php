<?php
	include('includes/connection.php');
	session_start();

	$id = $_GET['id'];
		
		$sql = "DELETE FROM user WHERE user_id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'user deleted successfully';
		}
		else{
			$_SESSION['error'] = 'Can not be deleted because it have been referenced';
		}

	header('location: Addreceptionist.php');
	
?>