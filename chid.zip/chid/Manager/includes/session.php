<?php
include('includes/connection.php');
session_start();
if(isset($_SESSION['Manager'])){;
   $sql = "SELECT * FROM user WHERE user_id = '".$_SESSION['Manager']."'";
   $query = $conn->query($sql);
   $curSession = $query->fetch_assoc();        

}

?>