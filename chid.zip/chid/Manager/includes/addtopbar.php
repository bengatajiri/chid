<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-success" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

         <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-success" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

          
        
            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-user-plus fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter"></span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                
          <form  action = "registeruser.php" method = "POST">     
            <div class="row">                                 
              <div class="col-lg-12">
              <div class="card shadow mb-4">
                <div class="card-header py-4">
                  <h6 class="m-0 font-weight-bold text-success">REGISTER NEW RECEPTIONIST</h6>
                </div>
                <div class="card-body">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="F_name" name="Fname" placeholder="first name" required>
                    </div> 
                     <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="L_name" name="Lname" placeholder="last name" required>
                    </div>                 
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="customer_phone" name="Phone" pattern="[+]{1}[2]{1}[5]{1}[5]{1}[0-9]{9}" minlength="13" title="Phone number must start with: +255 followed by any 9 digit" placeholder="Phone number" required>
                  </div>
                    <div class="form-group">
                      <input type="email" class="form-control form-control-user" id="customer_email" name="Email" placeholder="Email Address" required>
                  </div>
                            <div class="form-group">
                       <select class="form-control" name="Role">
       <option selected=""disabled select>select Role</option>
    <option value="Receptionist">Receptionist</option>
   
      </select>
                    </div>
                    <!-- fetch region from database -->
                     
                    <div class="form-group">
                       <select class="form-control" name="Region">
       <option selected=""disabled select>select Region</option>
        <?php
        include('connection.php');
                          $sql = "SELECT * FROM region";
                          $query = $conn->query($sql);
                          while($prow = $query->fetch_assoc()){
                            echo "
                              <option value='".$prow['region_id']."'>".$prow['region_name']."</option>
                            ";
                          }
                        ?>
      </select>
                    </div> 
                    <button type="submit" name="submit" class="btn btn-success btn-user btn-block">Register</button>
                                  
                </div> 
              </div>
            </div>
            </div>
            </form>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo($_SESSION['email']);?></span>
                <i class="fas fa-user-circle fa-sm"></i>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav> 
         <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-success" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
