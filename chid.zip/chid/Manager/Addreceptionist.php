
<?php
include ('includes/connection.php');
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<?php
include ('includes/header.php');

?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    
    <!-- Sidebar -->
    <?php include('includes/sidebar.php');?>
    


 <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">


        <!-- topbar -->
       
<?php include('includes/addtopbar.php'); ?>
           
        
   <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">BUS PARCEL MANAGEMENT STAFF</h1>
          <!-- Table body -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-success">List of registered staff members</h6>
            </div>
            <!-- update and delete  -->
            <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <!-- table header and search -->
                  <thead>
                    <tr>
                      <th>User_ID</th>
                      <th>Firstname</th>
                      <th>Lastname</th>
                      <th>Phone_no</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Region</th>
                       <th >action</th>
                     </tr>
                  </thead>
                   <tbody>
                    <?php
                    include('includes/connection.php');
                    ?>
                  <?php
                    $sql = "SELECT user_id, f_name, l_name, phone_no, email, role, region_name FROM user INNER JOIN region USING (region_id) WHERE role='Receptionist'";
                    $query1 = $conn->query($sql);
                    while($row = $query1->fetch_assoc()){
                      ?>
                        <tr>
                          <td><?php echo $row['user_id']; ?></td>
                          <td><?php echo $row['f_name']; ?></td>
                          <td><?php echo $row['l_name']; ?></td>
                          <td><?php echo $row['phone_no']; ?></td>
                          <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['role']; ?></td>
                          <td><?php echo $row['region_name']; ?></td>
                       <td>
                            <a href="receptionistform_edit.php?id=<?php echo $row['user_id']; ?>" class='btn bg-purple'><i class='fa fa-edit'></i></a> 
                            <a href="receptionist_delete.php?id=<?php echo $row['user_id']; ?>" class='btn bg-purple'><i class='fa fa-trash'></i></a> 
                          </td>
                           </tr>
                <?php
                    }
                  ?>    
                  
                </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        

      <?php 
      include('includes/connection.php');
      ?>
     

  

  <!-- scripts -->

      <?php 
      include('includes/script.php');
      ?>

</body>

</html>