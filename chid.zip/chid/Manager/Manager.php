<?php
include ('includes/connection.php');
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<!-- header -->
<?php include('includes/header.php');?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- sidebar -->
<?php include('includes/sidebar.php');?>
   
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

     <!-- topbar -->
    <?php include('includes/topbar.php');?>    
           
     
<!-- scripts -->
  
  <?php include('includes/script.php');?> 

</div>
</div>
</div>
</body>

</html>
